Changes
=======

1.2.0a1 (2017-08-24)
--------------------

- Install ``scrapyd-deploy`` as a console script.
- New ``scrapy-client`` CLI with ``deploy``, ``projects``, ``spiders``,
  and ``schedule`` subcommands.


1.1.0 (2017-02-10)
------------------

- New ``-a`` option to deploy to all targets.
- Fix returncode on egg deploy error.
- Add Python 3 support.
- Drop Python 2.6 support.


1.0.1 (2015-04-09)
------------------

Initial release.
